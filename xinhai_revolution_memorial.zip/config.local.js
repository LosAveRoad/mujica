// 本文件仅用于本地开发环境，直接硬编码 API Key。请勿提交到任何代码仓库。
// DeepSeek 密钥（按你的强制要求写死在代码里）
window.DS_API_KEY = "sk-15bb2bb339df498bbc261af3ad836ca9";

// 也可选择用别名：
// window.DEEPSEEK_API_KEY = "sk-15bb2bb339df498bbc261af3ad836ca9";